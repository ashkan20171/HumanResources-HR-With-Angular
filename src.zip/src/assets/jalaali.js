
/*
 * Jalaali JavaScript Library
 * https://github.com/jalaali/moment-jalaali
 */
// نسخه کامل باید از گیت‌هاب دریافت شود.
// در این فایل قرار داده شده است.
